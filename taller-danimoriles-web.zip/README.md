# Taller Danimoriles

Web estática lista para GitHub Pages.

## Publicación
1. Sube `index.html` a la raíz del repositorio.
2. En GitHub: Settings → Pages.
3. En "Build and deployment", selecciona "Deploy from a branch".
4. Selecciona la rama `main` y la carpeta `/ (root)`.
5. Guarda los cambios.

La web funciona sin Autodata. Puede integrarse más adelante.
